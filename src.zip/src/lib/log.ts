export const log = console;
