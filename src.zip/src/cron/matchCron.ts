// src/cron/matchCron.ts
import { Pool } from "pg";
import {
  getSlotsForDate,
  getEntriesForSlot,
  runMatchingForSlot,
  saveMatchesForSlot,
  assignTokensForSlot,
} from "../services/matching";

// JST 日付を YYYY-MM-DD 形式で取得
function getJstDateKey(offsetDays = 1): string {
  const now = new Date(Date.now() + 9 * 3600 * 1000); // JST
  const target = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + offsetDays
  );

  const yyyy = target.getFullYear();
  const mm = String(target.getMonth() + 1).padStart(2, "0");
  const dd = String(target.getDate()).padStart(2, "0");

  return `${yyyy}-${mm}-${dd}`;
}

/**
 * メイン関数
 *  - 翌日分の slot_dt を抽出
 *  - 各 slot_dt でマッチング実行
 *  - DB に保存
 *  - token を付与
 */
export async function executeMatchCron(pool: Pool) {
  const dateKey = getJstDateKey(1); // 翌日
  console.log(`[cron] target date = ${dateKey}`);

  // --- ① 翌日の slot_dt を取得（string として返る） ---
  const slotList = await getSlotsForDate(dateKey);
  console.log(`[cron] slots =`, slotList);

  if (slotList.length === 0) {
    return {
      ok: true,
      message: `no slots for ${dateKey}`,
      date: dateKey,
    };
  }

  const results = [];

  for (const slotDt of slotList) {
    console.log(`\n[cron] ===== slot ${slotDt} =====`);

    // --- ② エントリユーザ取得（slotDt は string のまま渡す） ---
    const entries = await getEntriesForSlot(slotDt);

    // --- location & type_mode は entries から抽出（仕様上、単一の想定） ---
    const locations = Array.from(new Set(entries.map((e) => e.location)));
    const types = Array.from(new Set(entries.map((e) => e.type_mode)));

    if (locations.length !== 1 || types.length !== 1) {
      console.warn(
        `[cron] inconsistent location/type_mode for slot=${slotDt}`,
        { locations, types }
      );
      continue;
    }

    const location = locations[0];
    const typeMode = types[0];

    // --- ③ マッチング実行 ---
    const { matched, unmatched } = runMatchingForSlot(entries);
    console.log(
      `[cron] matched groups=${matched.length}, unmatched users=${unmatched.length}`
    );

    // --- ④ DB 保存（string の slotDt を直接使用） ---
    await saveMatchesForSlot(pool, slotDt, location, typeMode, matched);

    // --- ⑤ token 付与 ---
    await assignTokensForSlot(pool, slotDt, location, typeMode);

    results.push({
      slotDt,
      matchedCount: matched.length,
      unmatchedCount: unmatched.length,
    });
  }

  return {
    ok: true,
    date: dateKey,
    slotCount: slotList.length,
    results,
  };
}

export default executeMatchCron;