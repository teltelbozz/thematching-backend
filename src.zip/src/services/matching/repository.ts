// src/services/matching/repository.ts
import { pool } from "../../db";

export async function getSlotsForDate(date: string): Promise<string[]> {
  const { rows } = await pool.query(
    `
    SELECT DISTINCT slot_dt
    FROM user_setup_slots
    WHERE slot_dt::date = $1::date
    ORDER BY slot_dt
    `,
    [date]
  );
  return rows.map((r: { slot_dt: string }) => r.slot_dt);
}

export async function getEntriesForSlot(slotDt: string) {
  const { rows } = await pool.query(
    `
    SELECT
      u.id AS user_id,
      p.gender AS gender,
      p.age AS age,
      s.type_mode AS type_mode,
      s.location AS location
    FROM user_setup s
    JOIN user_setup_slots sl ON sl.user_setup_id = s.id
    JOIN users u             ON u.id = s.user_id
    JOIN user_profiles p     ON p.user_id = u.id
    WHERE sl.slot_dt = $1
    ORDER BY u.id
    `,
    [slotDt]
  );

  return rows.map((r: any) => ({
    user_id: Number(r.user_id),
    gender: r.gender,
    age: Number(r.age),
    type_mode: r.type_mode,
    location: r.location,
  }));
}

export async function getHistoryEdges(): Promise<Set<string>> {
  const { rows } = await pool.query(`
    SELECT user_id_female, user_id_male FROM match_history
  `);

  const set = new Set<string>();
  for (const r of rows) {
    const a = Number(r.user_id_female);
    const b = Number(r.user_id_male);
    const key = `${Math.min(a, b)}-${Math.max(a, b)}`;
    set.add(key);
  }
  return set;
}